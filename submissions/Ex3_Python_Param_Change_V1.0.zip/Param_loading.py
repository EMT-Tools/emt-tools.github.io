#!/usr/bin/env python3

import mhi.pscad

# =====================================================
# USER INPUTS
# =====================================================

PROJECT_NAME = "Python_param_loading"

# Component names
component_names = [
    "Real1",
    "Real2",
    "Int1",
    "Int2"
]

# Corresponding values
component_values = [
    "1.5",
    "1.25",
    "2",
    "3"
]

# =====================================================
# MAIN
# =====================================================

# Basic validation
if len(component_names) != len(component_values):
    raise ValueError(
        "component_names and component_values must have the same length."
    )

with mhi.pscad.application() as pscad:

    # Try to load project
    try:
        prj = pscad.project(PROJECT_NAME)

        if prj is None:
            raise Exception(f'Project "{PROJECT_NAME}" was not found.')

    except Exception as e:
        print(f'ERROR: Failed to open project "{PROJECT_NAME}"')
        print(f'Details: {e}')
        raise

    # Loop through all parameters
    for name, value in zip(component_names, component_values):

        try:
            comp = prj.find_first(name)

            # Check if component exists
            if comp is None:
                print(f'WARNING: Component "{name}" was not found.')
                continue

            # Update parameter
            comp.parameters(Value=str(value))

            print(f'SUCCESS: {name} assigned {value}')

        except Exception as e:
            print(f'ERROR: Failed to update "{name}"')
            print(f'Details: {e}')